import Foundation

let myName = "Bartosz"
let yourName = "Foo"

var yourLastName = "Chou"

var names = [
    myName,
    yourName
]

names.append("Bart")
names.append("Adam")


let foo = "Foo"
var foo2 =  foo
foo2 = "Foo 2"
foo
foo2

let moreNames = [
    "Foo",
    "Bar"
]

var copy = moreNames
copy.append("Baz")
moreNames
copy

// example on how the let and var are mutable or unmutable

let oldArray = NSMutableArray( //this is the class instance
    array: [
        "Foo",
        "Boo"
    ]
) // so this oldArray is mutable because of the class

oldArray.add("Baz")
var newArray = oldArray
oldArray
newArray

// so here in the example above we can see that even if we use let it doesn't mean we will have unmutable variable


let someNames = NSMutableArray(
    array: [
        "Foo",
        "Boo"
    ]
)


func changeTheArray(_ array: NSArray) {
    let array2 = array as! NSMutableArray //here we are copying data from the array but we are chaging them to immutable data type
    array2.add("Baz")
}

changeTheArray(someNames)
someNames






