import Foundation

let myAge = 19
let yourAge = 20

if myAge > yourAge {
    "I'm older than you"
    ///returns true of the value on the left is higher
} else if myAge < yourAge {
    "I'm younger than you"
} else {
    "We are the same age"
}

let myMothersAge = myAge + 38
let doubleMyAge = myAge * 2

/// 1. unary prefix - working with one value e.g let foo = ! true here the ! is the unary prefix and it is before the value it comes to
/// 2. unary postfix - working with one value,
let name = Optional("Bart")
type(of: name)
let unaryPostFix = name!
type(of: unaryPostFix)
/// 3. binary infix - it is working with two values and it is sitting inbetween two values e.g > * / etc
let result = 1  + 2
let names = "Foo" + " " + "Bar"

/// Ternary operators operate on three targets.
//let age = 30

//this is example how we can solve it without the ternary operator
//let message: String
//if age >= 18 {
//    message = "You are an adult"
//    
//}else {
//    message = "You are not yet an adult"
//}


let age = 21
let message = age >= 18
    ? "You are an adult"
    : "You are not yet an adult"

